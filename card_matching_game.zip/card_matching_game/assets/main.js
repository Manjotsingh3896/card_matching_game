let currentRows, currentCols, currentGame, currentLevel = 1;
const rewards = { game1: [null, null, null], game2: [null, null, null], game3: [null, null, null], game4: [null, null, null] };

// Timer variables
let timerInterval, elapsedTime = 0;

// Move counter variable
let moveCount = 0;

// Basket tracking
let basketIndex = 0; // Tracks which basket to use (0 or 1)
let svgBasket1 = null; // Will hold reference to the first SVG basket
let svgBasket2 = null; // Will hold reference to the second SVG basket

// Reference to SVG reward elements
let svgWateringCan = null;
let svgSeedsBag = null;
let svgSoilBag = null;

function openPopup() {
    const popup = document.getElementById('popup');
    if (popup) {
        popup.style.display = 'flex';
        popup.style.zIndex = '1000';
    } else {
        console.error('Popup element not found');
    }
    
    // Handle instructions SVG interactivity if needed
    const instructionsSvg = document.getElementById('instructionsSvg');
    if (instructionsSvg) {
        instructionsSvg.addEventListener('load', function() {
            const svgDoc = instructionsSvg.contentDocument;
            if (!svgDoc) {
                console.error('Could not access instructions SVG document');
                return;
            }
            
            console.log('Instructions SVG loaded');
            
            // Make any close buttons in the SVG functional
            const closeButtons = [
                svgDoc.getElementById('close-button'),
                svgDoc.getElementById('closeButton'),
                svgDoc.querySelector('[id*="close"]'),
                svgDoc.querySelector('[id*="Close"]'),
                svgDoc.querySelector('[class*="close"]'),
                svgDoc.querySelector('[class*="Close"]')
            ].find(Boolean);
            
            if (closeButtons) {
                closeButtons.style.cursor = 'pointer';
                closeButtons.addEventListener('click', closePopup);
                console.log('Instructions close button integrated');
            }
        });
    }
}

function closePopup() {
    const popup = document.getElementById('popup');
    if (popup) {
        popup.style.display = 'none';
    }
}

function showFarmSelection() {
    console.log('showFarmSelection called');
    
    // Hide all game pages
    const gamePages = ['game1Page', 'game2Page', 'game3Page', 'game4Page'];
    gamePages.forEach(pageId => {
        const page = document.getElementById(pageId);
        if (page) page.style.display = 'none';
    });
    
    // Hide game board if visible
    const gameBoard = document.getElementById('gameBoardContainer');
    if (gameBoard) gameBoard.style.display = 'none';
    
    // Hide landing page
    const landingPage = document.getElementById('landingPage');
    if (landingPage) landingPage.style.display = 'none';
    
    // Close all popups
    const popups = ['popup', 'winPopupContainer', 'finalWinPopupContainer'];
    popups.forEach(popupId => {
        const popup = document.getElementById(popupId);
        if (popup) popup.style.display = 'none';
    });
    
    // Show farm selection page
    const farmSelectionPage = document.getElementById('farmSelectionPage');
    if (farmSelectionPage) {
        farmSelectionPage.style.display = 'flex';
        console.log('Navigation to farm selection completed');
    } else {
        console.error('Farm selection page not found');
    }
}

// Function to animate clouds
function animateClouds(svgDoc) {
    // Only animate if this is the title SVG
    if (!svgDoc.getElementById('cloud1') && !svgDoc.getElementById('cloud-2')) {
        return; // Skip animation for non-title SVGs
    }
    
    console.log('Starting cloud animation');
    
    // Find all cloud elements by their IDs
    const cloudIds = ['cloud1', 'cloud2', 'cloud3'];
    const clouds = cloudIds.map(id => svgDoc.getElementById(id)).filter(Boolean);
    
    // Define properties for each cloud
    const cloudConfig = {
        cloud1: {
            speed: 40,
            startX: -500,
            resetX: -1500  // Far left reset position
        },
        cloud2: {
            speed: 40,
            startX: -800,
            resetX: -1800  // Far left reset position
        },
        cloud3: {
            speed: 40,
            startX: -1100,
            resetX: -2100  // Far left reset position
        }
    };
    
    console.log('Found clouds:', clouds.length);
    console.log('Cloud elements:', clouds);
    
    const screenWidth = window.innerWidth;
    
    // Position and animate each cloud
    clouds.forEach((cloud) => {
        const config = cloudConfig[cloud.id];
        
        function moveCloud() {
            // First set to reset position
            gsap.set(cloud, { x: config.resetX });
            
            // Then animate to right edge
            gsap.to(cloud, {
                x: screenWidth + 100,   // Move to right edge
                duration: config.speed,  // Individual speed
                ease: 'none',
                onComplete: moveCloud    // Restart when done
            });
        }
        
        // Set initial position and start animation
        gsap.set(cloud, { x: config.startX });
        moveCloud();
    });
}

// Handle farm selection SVG interactions
function initFarmSelection() {
    const farmSvg = document.getElementById('farmSelectionSvg');
    
    farmSvg.addEventListener('load', function() {
        const svgDoc = farmSvg.contentDocument;
        
        // Farm IDs in the SVG
        const farmIds = ['spring-farm', 'summer-farm', 'fall-farm', 'winter-farm'];
        const gameMapping = {
            'spring-farm': 'game1',
            'summer-farm': 'game2',
            'fall-farm': 'game4',
            'winter-farm': 'game3'
        };
        
        // Add click handlers to each farm
        farmIds.forEach(farmId => {
            const farmElement = svgDoc.getElementById(farmId);
            if (farmElement) {
                farmElement.style.cursor = 'pointer';
                farmElement.addEventListener('click', () => {
                    const gameId = gameMapping[farmId];
                    goToGame(gameId);
                });
            }
        });
        
        // Integrate back and home buttons with SVG elements - try different possible selectors
        // Check for elements with exact id match, containing the name in id, or with a specified layer name
        const backButtonSelectors = [
            svgDoc.getElementById('go-back-button'),
            svgDoc.getElementById('back-button'),
            svgDoc.getElementById('back'),
            svgDoc.getElementById('backButton'),
            svgDoc.querySelector('[id*="back"]'),
            svgDoc.querySelector('[id*="Back"]'),
            svgDoc.querySelector('[class*="back"]'),
            svgDoc.querySelector('[class*="Back"]'),
            svgDoc.querySelector('g[id*="back"]'),
            svgDoc.querySelector('g[id*="Back"]'),
            svgDoc.querySelector('g[class*="back"]'),
            svgDoc.querySelector('g[class*="Back"]')
        ].find(Boolean);
        
        const homeButtonSelectors = [
            svgDoc.getElementById('home-button'),
            svgDoc.getElementById('home'),
            svgDoc.getElementById('homeButton'),
            svgDoc.querySelector('[id*="home"]'),
            svgDoc.querySelector('[id*="Home"]'),
            svgDoc.querySelector('[class*="home"]'),
            svgDoc.querySelector('[class*="Home"]'),
            svgDoc.querySelector('g[id*="home"]'),
            svgDoc.querySelector('g[id*="Home"]'),
            svgDoc.querySelector('g[class*="home"]'),
            svgDoc.querySelector('g[class*="Home"]')
        ].find(Boolean);
        
        // Log all elements in the SVG to help debugging
        console.log('All SVG elements in farm selection:');
        const allElements = Array.from(svgDoc.querySelectorAll('*'));
        allElements.forEach(el => {
            if (el.id || el.classList.length > 0) {
                console.log(`Element: ${el.tagName}, ID: ${el.id}, Class: ${el.className}`);
            }
        });
        
        // Get references to HTML buttons
        const backButtonHtml = document.getElementById('backButton');
        const homeButtonHtml = document.getElementById('homeButton');
        
        if (backButtonSelectors) {
            console.log('Back button SVG found:', backButtonSelectors);
            backButtonSelectors.style.cursor = 'pointer';
            backButtonSelectors.addEventListener('click', goBackToLanding);
            console.log('Back button SVG integrated');
            
            // Hide the HTML back button since SVG button is functional
            if (backButtonHtml) {
                backButtonHtml.classList.add('hidden');
            }
        } else {
            console.log('Back button SVG element not found');
        }
        
        if (homeButtonSelectors) {
            console.log('Home button SVG found:', homeButtonSelectors);
            homeButtonSelectors.style.cursor = 'pointer';
            homeButtonSelectors.addEventListener('click', goBackToLanding);
            console.log('Home button SVG integrated');
            
            // Hide the HTML home button since SVG button is functional
            if (homeButtonHtml) {
                homeButtonHtml.classList.add('hidden');
            }
        } else {
            console.log('Home button SVG element not found');
        }
    });
}

// Function to initialize game screen
function initGameScreen() {
    const gameScreenSvg = document.getElementById('gameScreenSvg');
    
    if (gameScreenSvg) {
        // Remove previous load event listeners to avoid duplicates
        const newGameScreenSvg = gameScreenSvg.cloneNode(true);
        gameScreenSvg.parentNode.replaceChild(newGameScreenSvg, gameScreenSvg);
        
        // Force reload of the SVG to ensure it's fresh
        newGameScreenSvg.data = newGameScreenSvg.data;
        
        newGameScreenSvg.addEventListener('load', function() {
            console.log('Game screen SVG loaded/reloaded');
            const svgDoc = newGameScreenSvg.contentDocument;
            
            if (!svgDoc) {
                console.error('Could not access SVG document');
                return;
            }
            
            // Log all elements in the SVG to help debugging
            console.log('All SVG elements in game screen:');
            const allElements = Array.from(svgDoc.querySelectorAll('*'));
            allElements.forEach(el => {
                if (el.id || el.classList.length > 0) {
                    console.log(`Element: ${el.tagName}, ID: ${el.id}, Class: ${el.className}`);
                }
            });
            
            // Find back button in game screen SVG - try different possible selectors
            const backButtonSelectors = [
                svgDoc.getElementById('go-back-button'),
                svgDoc.getElementById('back-button'),
                svgDoc.getElementById('back'),
                svgDoc.getElementById('backButton'),
                svgDoc.querySelector('[id*="back"]'),
                svgDoc.querySelector('[id*="Back"]'),
                svgDoc.querySelector('[class*="back"]'),
                svgDoc.querySelector('[class*="Back"]'),
                svgDoc.querySelector('g[id*="back"]'),
                svgDoc.querySelector('g[id*="Back"]'),
                svgDoc.querySelector('g[class*="back"]'),
                svgDoc.querySelector('g[class*="Back"]'),
                // Try to find the button element in the buttons group
                svgDoc.querySelector('#buttons rect:first-child'),
                svgDoc.querySelector('#buttons g:first-child')
            ].find(Boolean);
            
            // Find home button in game screen SVG - try different possible selectors
            const homeButtonSelectors = [
                svgDoc.getElementById('home-button'),
                svgDoc.getElementById('home'),
                svgDoc.getElementById('homeButton'),
                svgDoc.querySelector('[id*="home"]'),
                svgDoc.querySelector('[id*="Home"]'),
                svgDoc.querySelector('[class*="home"]'),
                svgDoc.querySelector('[class*="Home"]'),
                svgDoc.querySelector('g[id*="home"]'),
                svgDoc.querySelector('g[id*="Home"]'),
                svgDoc.querySelector('g[class*="home"]'),
                svgDoc.querySelector('g[class*="Home"]'),
                // Try to find the home button in the buttons group (usually second button)
                svgDoc.querySelector('#buttons rect:nth-child(2)'),
                svgDoc.querySelector('#buttons g:nth-child(2)')
            ].find(Boolean);
            
            const gameBackButtonHtml = document.getElementById('gameBackButton');
            const gameHomeButtonHtml = document.getElementById('gameHomeButton');
            
            if (backButtonSelectors) {
                console.log('Game screen back button found:', backButtonSelectors);
                backButtonSelectors.style.cursor = 'pointer';
                backButtonSelectors.addEventListener('click', goBackToGamePage);
                console.log('Game screen back button integrated');
                
                // Hide the HTML back button since SVG button is functional
                if (gameBackButtonHtml) {
                    gameBackButtonHtml.classList.add('hidden');
                }
            } else {
                console.log('Game screen back button not found in SVG');
            }
            
            if (homeButtonSelectors) {
                console.log('Game screen home button found:', homeButtonSelectors);
                homeButtonSelectors.style.cursor = 'pointer';
                homeButtonSelectors.addEventListener('click', goBackToLanding);
                console.log('Game screen home button integrated');
                
                // Hide the HTML home button since SVG button is functional
                if (gameHomeButtonHtml) {
                    gameHomeButtonHtml.classList.add('hidden');
                }
            } else {
                console.log('Game screen home button not found in SVG');
            }
            
            // Get references to SVG basket elements
            const fruitsBasket = svgDoc.getElementById('fruits-basket');
            const rootsBasket = svgDoc.getElementById('roots-basket');
            
            // Store the basket references globally
            svgBasket1 = fruitsBasket;
            svgBasket2 = rootsBasket;
            
            // Get references to the reward items in SVG
            const rewardGroup = svgDoc.getElementById('reward');
            svgWateringCan = svgDoc.getElementById('wateringCan');
            svgSeedsBag = svgDoc.getElementById('seedsBag');
            svgSoilBag = svgDoc.getElementById('soilBag');
            
            console.log('Found reward elements:', {
                rewardGroup: rewardGroup ? 'yes' : 'no',
                wateringCan: svgWateringCan ? 'yes' : 'no',
                seedsBag: svgSeedsBag ? 'yes' : 'no',
                soilBag: svgSoilBag ? 'yes' : 'no'
            });
            
            // Hide all rewards initially, they'll be shown based on level completion
            if (svgWateringCan) svgWateringCan.style.opacity = '0';
            if (svgSeedsBag) svgSeedsBag.style.opacity = '0';
            if (svgSoilBag) svgSoilBag.style.opacity = '0';
            
            // Update reward visibility based on current game's rewards
            updateSvgRewards();
            
            // Create container groups for holding cards in each basket
            let fruitsGroup = svgDoc.getElementById('fruits-items');
            if (!fruitsGroup) {
                fruitsGroup = svgDoc.createElementNS("http://www.w3.org/2000/svg", "g");
                fruitsGroup.id = "fruits-items";
            }
            
            let rootsGroup = svgDoc.getElementById('roots-items');
            if (!rootsGroup) {
                rootsGroup = svgDoc.createElementNS("http://www.w3.org/2000/svg", "g");
                rootsGroup.id = "roots-items";
            }
            
            // Add the groups to the SVG
            if (fruitsBasket) {
                // Make sure the fruits basket itself has a pointer cursor
                fruitsBasket.style.cursor = 'pointer';
                
                // Check if the group is already a child of the basket
                if (!fruitsBasket.querySelector('#fruits-items')) {
                    fruitsBasket.appendChild(fruitsGroup);
                }
                
                // Create a popup div for showing fruits
                let fruitsPopup = document.getElementById('fruits-popup');
                if (!fruitsPopup) {
                    fruitsPopup = document.createElement('div');
                    fruitsPopup.id = 'fruits-popup';
                    fruitsPopup.className = 'basket-popup';
                    fruitsPopup.innerHTML = '<h3>Fruits Basket</h3><div class="popup-items"></div>';
                    document.body.appendChild(fruitsPopup);
                }
                
                // Add hover effects for the fruits basket
                fruitsBasket.addEventListener('mouseenter', function(e) {
                    // Position the popup near the basket
                    const basketRect = fruitsBasket.getBoundingClientRect();
                    fruitsPopup.style.left = (basketRect.left + basketRect.width/2 - 100) + 'px';
                    fruitsPopup.style.top = (basketRect.top - 200) + 'px';
                    fruitsPopup.style.display = 'block';
                    
                    // Display the items in the popup
                    const itemsContainer = fruitsPopup.querySelector('.popup-items');
                    itemsContainer.innerHTML = '';
                    
                    // Get all collected fruit items
                    const fruitItems = JSON.parse(localStorage.getItem('fruitItems') || '[]');
                    
                    if (fruitItems.length === 0) {
                        itemsContainer.innerHTML = '<p>No fruits collected yet</p>';
                    } else {
                        fruitItems.forEach(item => {
                            const imgElement = document.createElement('img');
                            imgElement.src = item;
                            imgElement.className = 'popup-item';
                            imgElement.alt = 'Collected fruit';
                            imgElement.style.width = '40px';
                            imgElement.style.height = '40px';
                            imgElement.style.objectFit = 'cover';
                            imgElement.style.objectPosition = 'center';
                            imgElement.style.borderRadius = '5px';
                            imgElement.style.border = '1px solid #ddd';
                            itemsContainer.appendChild(imgElement);
                        });
                    }
                });
                
                fruitsBasket.addEventListener('mouseleave', function() {
                    const fruitsPopup = document.getElementById('fruits-popup');
                    if (fruitsPopup) {
                        fruitsPopup.style.display = 'none';
                    }
                });
            }
            
            if (rootsBasket) {
                // Make sure the roots basket itself has a pointer cursor
                rootsBasket.style.cursor = 'pointer';
                
                // Check if the group is already a child of the basket
                if (!rootsBasket.querySelector('#roots-items')) {
                    rootsBasket.appendChild(rootsGroup);
                }
                
                // Create a popup div for showing roots
                let rootsPopup = document.getElementById('roots-popup');
                if (!rootsPopup) {
                    rootsPopup = document.createElement('div');
                    rootsPopup.id = 'roots-popup';
                    rootsPopup.className = 'basket-popup';
                    rootsPopup.innerHTML = '<h3>Roots Basket</h3><div class="popup-items"></div>';
                    document.body.appendChild(rootsPopup);
                }
                
                // Add hover effects for the roots basket
                rootsBasket.addEventListener('mouseenter', function() {
                    // Position the popup near the basket
                    const basketRect = rootsBasket.getBoundingClientRect();
                    rootsPopup.style.left = (basketRect.left + basketRect.width/2 - 100) + 'px';
                    rootsPopup.style.top = (basketRect.top - 200) + 'px';
                    rootsPopup.style.display = 'block';
                    
                    // Display the items in the popup
                    const itemsContainer = rootsPopup.querySelector('.popup-items');
                    itemsContainer.innerHTML = '';
                    
                    // Get all collected root items
                    const rootItems = JSON.parse(localStorage.getItem('rootItems') || '[]');
                    
                    if (rootItems.length === 0) {
                        itemsContainer.innerHTML = '<p>No roots collected yet</p>';
                    } else {
                        rootItems.forEach(item => {
                            const imgElement = document.createElement('img');
                            imgElement.src = item;
                            imgElement.className = 'popup-item';
                            imgElement.alt = 'Collected root';
                            imgElement.style.width = '40px';
                            imgElement.style.height = '40px';
                            imgElement.style.objectFit = 'cover';
                            imgElement.style.objectPosition = 'center';
                            imgElement.style.borderRadius = '5px';
                            imgElement.style.border = '1px solid #ddd';
                            itemsContainer.appendChild(imgElement);
                        });
                    }
                });
                
                rootsBasket.addEventListener('mouseleave', function() {
                    const rootsPopup = document.getElementById('roots-popup');
                    if (rootsPopup) {
                        rootsPopup.style.display = 'none';
                    }
                });
            }
            
            console.log('Fruits Basket:', fruitsBasket);
            console.log('Roots Basket:', rootsBasket);
        });
    }
}

// Function to handle theme level pages SVGs and make level buttons clickable
function initThemeLevelPages() {
    // Map theme SVG objects to their game IDs
    const themeSvgMapping = {
        'theme-one-levelpage': 'game1',
        'theme-two-levelpage': 'game2',
        'theme-three-levelpage': 'game3',
        'theme-four-levelpage': 'game4'
    };
    
    // Level parameters mapping
    const levelParams = {
        'one': { rows: 2, cols: 3 },
        'two': { rows: 3, cols: 4 },
        'three': { rows: 4, cols: 5 }
    };
    
    // Convert level name to number
    const levelNameToNumber = {
        'one': 1,
        'two': 2,
        'three': 3
    };
    
    // Process each theme SVG
    Object.keys(themeSvgMapping).forEach(themeId => {
        const themeSvgObject = document.getElementById(themeId);
        const gameId = themeSvgMapping[themeId];
        const themePrefix = themeId.split('-')[0] + '-' + themeId.split('-')[1]; // e.g., "theme-one"
        
        if (themeSvgObject) {
            themeSvgObject.addEventListener('load', function() {
                const svgDoc = themeSvgObject.contentDocument;
                
                if (svgDoc) {
                    console.log(`${themeId} SVG loaded`);
                    
                    // Debug: Log all elements with ID
                    const allElements = Array.from(svgDoc.querySelectorAll('[id]'));
                    console.log(`SVG elements with IDs in ${themeId}:`, allElements.map(el => ({ id: el.id, tagName: el.tagName })));
                    
                    // Track if we found any level buttons
                    let foundLevelButtons = false;
                    
                    // Process each level button with its specific ID
                    ['one', 'two', 'three'].forEach(levelName => {
                        const buttonId = `${themePrefix}-level-${levelName}`;
                        const levelButton = svgDoc.getElementById(buttonId);
                        
                        if (levelButton) {
                            console.log(`Found level button with ID ${buttonId}`);
                            foundLevelButtons = true;
                            
                            // Make the button and all its children interactive
                            levelButton.style.cursor = 'pointer';
                            levelButton.style.pointerEvents = 'all';
                            
                            // Also apply to children
                            const children = levelButton.querySelectorAll('*');
                            children.forEach(child => {
                                child.style.cursor = 'pointer';
                                child.style.pointerEvents = 'all';
                            });
                            
                            // Add visual feedback
                            levelButton.addEventListener('mouseover', function() {
                                // For rect elements, change fill
                                const rects = levelButton.querySelectorAll('rect');
                                rects.forEach(rect => {
                                    // Store original fill
                                    if (!rect._originalFill) {
                                        rect._originalFill = rect.getAttribute('fill');
                                    }
                                    // Apply hover fill (slightly lighter)
                                    rect.setAttribute('fill', '#FF9500');
                                });
                                
                                // For text elements, change color
                                const texts = levelButton.querySelectorAll('text');
                                texts.forEach(text => {
                                    if (!text._originalFill) {
                                        text._originalFill = text.getAttribute('fill');
                                    }
                                    text.setAttribute('fill', '#FFFFFF');
                                });
                                
                                // If the button itself is a shape element
                                if (levelButton.tagName === 'rect' || levelButton.tagName === 'circle') {
                                    if (!levelButton._originalFill) {
                                        levelButton._originalFill = levelButton.getAttribute('fill');
                                    }
                                    levelButton.setAttribute('fill', '#FF9500');
                                }
                                
                                // If the button itself is text
                                if (levelButton.tagName === 'text') {
                                    if (!levelButton._originalFill) {
                                        levelButton._originalFill = levelButton.getAttribute('fill');
                                    }
                                    levelButton.setAttribute('fill', '#FFFFFF');
                                }
                            });
                            
                            levelButton.addEventListener('mouseout', function() {
                                // Restore original fill for rects
                                const rects = levelButton.querySelectorAll('rect');
                                rects.forEach(rect => {
                                    if (rect._originalFill) {
                                        rect.setAttribute('fill', rect._originalFill);
                                    }
                                });
                                
                                // Restore original fill for texts
                                const texts = levelButton.querySelectorAll('text');
                                texts.forEach(text => {
                                    if (text._originalFill) {
                                        text.setAttribute('fill', text._originalFill);
                                    }
                                });
                                
                                // Restore for button itself if it's a shape
                                if ((levelButton.tagName === 'rect' || levelButton.tagName === 'circle') && levelButton._originalFill) {
                                    levelButton.setAttribute('fill', levelButton._originalFill);
                                }
                                
                                // Restore for button itself if it's text
                                if (levelButton.tagName === 'text' && levelButton._originalFill) {
                                    levelButton.setAttribute('fill', levelButton._originalFill);
                                }
                            });
                            
                            // Add click handler
                            levelButton.addEventListener('click', function(e) {
                                e.preventDefault();
                                e.stopPropagation();
                                
                                const { rows, cols } = levelParams[levelName];
                                const level = levelNameToNumber[levelName];
                                
                                console.log(`Level button ${buttonId} clicked, starting game with rows: ${rows}, cols: ${cols}, game: ${gameId}, level: ${level}`);
                                startGame(rows, cols, gameId, level);
                            });
                        } else {
                            console.log(`Could not find level button with ID ${buttonId}`);
                        }
                    });
                    
                    if (!foundLevelButtons) {
                        console.log(`No level buttons found in ${themeId}, creating fallback buttons`);
                        createFallbackLevelButtons(gameId, themeId);
                    }
                } else {
                    console.error(`Could not access ${themeId} SVG document`);
                }
            });
        } else {
            console.error(`${themeId} SVG not found`);
        }
    });
}

// Function to create fallback buttons for levels when SVG buttons can't be found
function createFallbackLevelButtons(gameId, themeId) {
    console.log(`Creating fallback buttons for ${gameId} with theme ${themeId}`);
    
    const gamePage = document.getElementById(`${gameId}Page`);
    if (!gamePage) return;
    
    // Check if fallback buttons already exist
    if (gamePage.querySelector('.fallback-level-buttons')) return;
    
    // Create a container for fallback buttons
    const fallbackContainer = document.createElement('div');
    fallbackContainer.className = 'fallback-level-buttons';
    fallbackContainer.style.position = 'absolute';
    fallbackContainer.style.zIndex = '10';
    fallbackContainer.style.display = 'flex';
    fallbackContainer.style.justifyContent = 'center';
    fallbackContainer.style.gap = '20px';
    fallbackContainer.style.width = '100%';
    fallbackContainer.style.top = '50%';
    fallbackContainer.style.left = '0';
    
    // Level parameters mapping
    const levelParams = {
        'one': { rows: 2, cols: 3 },
        'two': { rows: 3, cols: 4 },
        'three': { rows: 4, cols: 5 }
    };
    
    // Convert level name to number
    const levelNameToNumber = {
        'one': 1,
        'two': 2,
        'three': 3
    };
    
    // Add three level buttons
    ['one', 'two', 'three'].forEach(levelName => {
        const button = document.createElement('button');
        button.textContent = `Level ${levelNameToNumber[levelName]}`;
        button.className = 'fallback-level-button';
        button.style.padding = '15px 30px';
        button.style.fontSize = '18px';
        button.style.backgroundColor = '#ff9500';
        button.style.color = 'white';
        button.style.border = 'none';
        button.style.borderRadius = '10px';
        button.style.cursor = 'pointer';
        button.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
        
        button.addEventListener('click', function() {
            const { rows, cols } = levelParams[levelName];
            const level = levelNameToNumber[levelName];
            
            console.log(`Fallback button level ${levelName} clicked, starting game with rows: ${rows}, cols: ${cols}, game: ${gameId}, level: ${level}`);
            startGame(rows, cols, gameId, level);
        });
        
        fallbackContainer.appendChild(button);
    });
    
    gamePage.style.position = 'relative';
    gamePage.appendChild(fallbackContainer);
    
    console.log(`Added fallback buttons to ${gameId}`);
}

// Add event listener for SVG buttons
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded');
    const svgObject = document.getElementById('titleSvg');
    console.log('SVG Object:', svgObject);
    
    if (svgObject) {
        svgObject.addEventListener('load', function() {
            const svgDoc = svgObject.contentDocument;
            initializeSVGButtons(svgDoc);
        });
    }
    
    // Initialize farm selection SVG
    initFarmSelection();
    
    // Initialize game screen SVG
    initGameScreen();
    
    // Initialize theme level pages
    initThemeLevelPages();
    
    // Handle farm selection SVG
    const farmSvg = document.getElementById('farmSelectionSvg');
    console.log('Farm SVG Object:', farmSvg);
    
    if (farmSvg) {
        farmSvg.addEventListener('load', function() {
            console.log('Farm SVG loaded');
            const svgDoc = farmSvg.contentDocument;
            
            if (svgDoc) {
                // Debug: Log all elements to see what we have
                const allElements = Array.from(svgDoc.getElementsByTagName('*'));
                console.log('All SVG elements:', allElements.map(el => ({ id: el.id, tagName: el.tagName })));
                
                // Farm mappings (autumn -> game1, summer -> game2, winter -> game3, spring -> game4)
                const farmMappings = {
                    'autumn': 'game1',
                    'summer': 'game2',
                    'winter': 'game3',
                    'spring': 'game4'
                };
                
                // Find all elements that might be part of each farm
                Object.keys(farmMappings).forEach(farmName => {
                    // Try different possible ID patterns
                    const possibleSelectors = [
                        `#${farmName}`,
                        `#${farmName}-farm`,
                        `#${farmName}_farm`,
                        `[id*="${farmName}"]`,
                        `[class*="${farmName}"]`
                    ];
                    
                    // Try each selector
                    possibleSelectors.forEach(selector => {
                        const elements = svgDoc.querySelectorAll(selector);
                        elements.forEach(element => {
                            console.log(`Found ${farmName} element:`, element);
                            
                            // Make element and its children clickable
                            element.style.cursor = 'pointer';
                            element.style.pointerEvents = 'all';
                            
                            // Add click handler
                            element.addEventListener('click', function(e) {
                                console.log(`${farmName} farm clicked, going to ${farmMappings[farmName]}`);
                                e.preventDefault();
                                e.stopPropagation();
                                goToGame(farmMappings[farmName]);
                            });
                        });
                    });
                });
            } else {
                console.error('Could not access SVG document');
            }
        });
    } else {
        console.error('Farm SVG not found in document');
    }
    
    function initializeSVGButtons(svgDoc) {
        console.log('Initializing SVG buttons');
        
        // Function to check if an element is within the button areas
        function isInButtonArea(element) {
            try {
                const rect = element.getBoundingClientRect();
                const svgRect = svgDoc.documentElement.getBoundingClientRect();
                const relativeY = (rect.top - svgRect.top) / svgRect.height;
                
                // Button areas are typically in the middle-bottom portion of the SVG
                // Adjust these values based on your specific SVG layout
                return relativeY > 0.4 && relativeY < 0.8;
            } catch (e) {
                return false;
            }
        }
        
        // Find all potential button elements
        const buttonElements = svgDoc.querySelectorAll('rect, text');
        console.log('Found potential button elements:', buttonElements.length);
        
        buttonElements.forEach((element, index) => {
            if (isInButtonArea(element)) {
                console.log(`Making element ${index} interactive:`, element);
                
                // Make element interactive
                element.style.cursor = 'pointer';
                element.style.pointerEvents = 'all';
                
                // Add click handler
                element.addEventListener('click', function(e) {
                    console.log('Button clicked:', this);
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const rect = this.getBoundingClientRect();
                    const svgRect = svgDoc.documentElement.getBoundingClientRect();
                    const relativeY = (rect.top - svgRect.top) / svgRect.height;
                    
                    // Determine which button was clicked based on position
                    if (relativeY < 0.6) {
                        console.log('Play button clicked');
                        showFarmSelection();
                    } else if (relativeY >= 0.6) {
                        console.log('How to Play button clicked');
                        openPopup();
                    }
                });
                
                // Add hover effects
                element.addEventListener('mouseover', function() {
                    this.style.opacity = '0.8';
                });
                
                element.addEventListener('mouseout', function() {
                    this.style.opacity = '1';
                });
            } else {
                // Ensure non-button elements are not interactive
                element.style.pointerEvents = 'none';
                element.style.cursor = 'default';
            }
        });
    }
    
    // Handle SVG load
    svgObject.addEventListener('load', function() {
        console.log('SVG loaded');
        const svgDoc = svgObject.contentDocument;
        if (svgDoc) {
            console.log('SVG document found');
            initializeSVGButtons(svgDoc);
            // Start cloud animation
            animateClouds(svgDoc);
        } else {
            console.error('No SVG document found');
        }
    });
    
    // Check if SVG is already loaded
    if (svgObject.contentDocument && svgObject.contentDocument.readyState === 'complete') {
        console.log('SVG already loaded');
        initializeSVGButtons(svgObject.contentDocument);
    }
});

function goToGame(game) {
    document.getElementById('farmSelectionPage').style.display = 'none';
    document.getElementById(`${game}Page`).style.display = 'block';
    currentGame = game;
}

function goBackToLanding() {
    document.querySelectorAll('.game-page').forEach(page => page.style.display = 'none');
    document.getElementById('farmSelectionPage').style.display = 'flex';
    document.getElementById('landingPage').style.display = 'flex';
    document.getElementById('winPopupContainer').style.display = 'none';
    document.getElementById('finalWinPopupContainer').style.display = 'none';
    currentGame = null;
    currentLevel = 1;
    resetGameStats();
    
    // Clear the fruit and root collections when returning to landing page
    localStorage.setItem('fruitItems', JSON.stringify([]));
    localStorage.setItem('rootItems', JSON.stringify([]));
    
    // Reset basket index counter
    basketIndex = 0;
}

function startGame(rows, cols, game, level) {
    console.log(`Starting game with rows: ${rows}, cols: ${cols}, game: ${game}, level: ${level}`);
    
    currentRows = rows;
    currentCols = cols;
    currentGame = game;
    currentLevel = level;
    
    resetGameStats();
    
    // Clear the fruit and root collections when starting a new game
    localStorage.setItem('fruitItems', JSON.stringify([]));
    localStorage.setItem('rootItems', JSON.stringify([]));
    
    // Reset basket index counter
    basketIndex = 0;
    
    // Hide the game page
    document.getElementById(`${game}Page`).style.display = 'none';
    
    // Show the game board
    const gameBoard = document.getElementById('gameBoardContainer');
    gameBoard.style.display = 'flex';
    
    // Hide the reward placeholders in the HTML (since we're using SVG rewards now)
    const rewardContainers = document.querySelectorAll('.reward-container');
    rewardContainers.forEach(container => {
        container.style.display = 'none';
    });
    
    // Initialize game screen SVG
    initGameScreen();
    
    // Reset game stats for new level
    resetGameStats();

    const totalCards = rows * cols;
    if (totalCards % 2 !== 0) return;

    const gameBoardElement = document.getElementById("gameBoard");
    gameBoardElement.innerHTML = "";
    gameBoardElement.style.gridTemplateColumns = `repeat(${cols}, 100px)`;
    gameBoardElement.style.gridTemplateRows = `repeat(${rows}, 130px)`;
    gameBoardElement.style.gap = "15px";

    // Define season-specific image sets
    const seasonImages = {
        game1: [ // Spring farm images
            "./assets/images/spring/tulip.jpg",
            "./assets/images/spring/daffodil.jpg",
            "./assets/images/spring/cherry_blossom.jpg",
            "./assets/images/spring/iris.jpg",
            "./assets/images/spring/daisy.jpg",
            "./assets/images/spring/lilac.jpg",
            "./assets/images/spring/pansy.jpg",
            "./assets/images/spring/hyacinth.jpg",
            "./assets/images/spring/magnolia.jpg",
            "./assets/images/spring/lily.jpg"
        ],
        game2: [ // Summer farm images
            "./assets/images/summerCards/lemon.svg",
            "./assets/images/summerCards/pears.svg",
            "./assets/images/summerCards/beetroot.svg",
            "./assets/images/summerCards/avocado.svg",
            "./assets/images/summerCards/tomato.svg",
            "./assets/images/summerCards/sweetpatato.svg",
            "./assets/images/summerCards/carrot.svg",
            "./assets/images/summerCards/apple.svg",
            "./assets/images/summerCards/grapes.svg",
            "./assets/images/summerCards/strawbarry.svg",
            "./assets/images/summerCards/turnip.svg",
            "./assets/images/summerCards/daikon.svg",
            "./assets/images/summerCards/onion.svg",
        ],
        game3: [ // Fall farm images
            "./assets/images/fall/pumpkin.jpg",
            "./assets/images/fall/apple.jpg",
            "./assets/images/fall/maple_leaf.jpg",
            "./assets/images/fall/acorn.jpg",
            "./assets/images/fall/wheat.jpg",
            "./assets/images/fall/corn.jpg",
            "./assets/images/fall/grape.jpg",
            "./assets/images/fall/mushroom.jpg",
            "./assets/images/fall/chrysanthemum.jpg",
            "./assets/images/fall/squash.jpg"
        ],
        game4: [ // Winter farm images
            "./assets/images/winter/snowflake.jpg",
            "./assets/images/winter/pine_cone.jpg",
            "./assets/images/winter/holly.jpg",
            "./assets/images/winter/mistletoe.jpg",
            "./assets/images/winter/winter_berry.jpg",
            "./assets/images/winter/evergreen.jpg",
            "./assets/images/winter/icicle.jpg",
            "./assets/images/winter/frost_leaf.jpg",
            "./assets/images/winter/snow_covered_pine.jpg",
            "./assets/images/winter/cardinal.jpg"
        ]
    };

    // Select the appropriate image set based on the current game
    const images = seasonImages[game];

    let cardValues = [];
    for (let i = 0; i < totalCards / 2; i++) {
        cardValues.push(images[i]);
        cardValues.push(images[i]);
    }
    cardValues = cardValues.sort(() => Math.random() - 0.5);

    let selectedCards = [];
    let matchedCards = [];
    let cards = [];

    // Start the timer
    startTimer();

    for (let value of cardValues) {
        const card = document.createElement("div");
        card.classList.add("card");
        card.dataset.value = value;
        card.style.borderRadius = "10px";
        card.style.overflow = "hidden";
        card.style.boxShadow = "0 4px 8px rgba(0,0,0,0.2)";

        const cardInner = document.createElement("div");
        cardInner.classList.add("card-inner");
        cardInner.style.width = "100%";
        cardInner.style.height = "100%";
        cardInner.style.position = "relative";
        cardInner.style.transformStyle = "preserve-3d";
        cardInner.style.transition = "transform 0.6s";
        
        const cardFront = document.createElement("div");
        cardFront.classList.add("card-front");
        cardFront.style.display = "flex";
        cardFront.style.alignItems = "center";
        cardFront.style.justifyContent = "center";
        cardFront.style.fontSize = "2em";
        cardFront.style.color = "#333";
        cardFront.style.fontWeight = "bold";
        cardFront.style.borderRadius = "10px";
        cardFront.style.border = "1px solid #ddd";
        cardFront.style.backgroundColor = "transparent";
        cardFront.style.position = "absolute";
        cardFront.style.width = "100%";
        cardFront.style.height = "100%";
        cardFront.style.backfaceVisibility = "hidden";
        
        // Create back card image instead of text
        const backImg = document.createElement("img");
        backImg.src = "./assets/images/cardBack.svg";
        backImg.alt = "Card Back";
        backImg.style.width = "100%";
        backImg.style.height = "100%";
        backImg.style.objectFit = "cover";
        backImg.style.objectPosition = "center";
        backImg.style.borderRadius = "10px";
        backImg.style.margin = "0";
        backImg.style.padding = "0";
        backImg.style.display = "block"; // Ensures the image is treated as a block element
        cardFront.appendChild(backImg);

        const cardBack = document.createElement("div");
        cardBack.classList.add("card-back");
        cardBack.style.position = "absolute";
        cardBack.style.width = "100%";
        cardBack.style.height = "100%";
        cardBack.style.backfaceVisibility = "hidden";
        cardBack.style.transform = "rotateY(180deg)";
        cardBack.style.borderRadius = "10px";
        cardBack.style.overflow = "hidden";
        
        const img = document.createElement("img");
        img.src = value;
        img.alt = "Card Image";
        img.style.width = "100%";
        img.style.height = "100%";
        img.style.objectFit = "cover";
        img.style.objectPosition = "center";
        img.style.display = "block";
        cardBack.appendChild(img);
        cardInner.appendChild(cardFront);
        cardInner.appendChild(cardBack);
        card.appendChild(cardInner);
        cards.push(card);

        card.addEventListener("click", function () {
            if (matchedCards.includes(card) || selectedCards.length >= 2) return;

            // Increment move count
            moveCount++;
            updateMoveCounter();

            card.classList.add("flipped");
            selectedCards.push(card);
            if (selectedCards.length === 2) {
                setTimeout(() => {
                    if (selectedCards[0].dataset.value === selectedCards[1].dataset.value) {
                        selectedCards.forEach(c => c.classList.add("matched"));
                        matchedCards.push(...selectedCards);

                        // Add matched image to a basket
                        addToBasket(selectedCards[0].dataset.value);

                    } else {
                        selectedCards.forEach(c => c.classList.remove("flipped"));
                    }
                    selectedCards = [];

                    if (matchedCards.length === totalCards) {
                        setTimeout(() => {
                            // Stop the timer
                            stopTimer();

                            // Add reward for the completed level
                            rewards[currentGame][currentLevel - 1] = `Reward ${currentLevel}`;
                            updateRewardsOnBothPages();

                            // Show win popup with stats
                            showWinPopup();
                        }, 500);
                    }
                }, 1000);
            }
        });
        gameBoardElement.appendChild(card);
    }

    // Preview all cards before gameplay starts
    cards.forEach(card => card.classList.add("flipped"));
    setTimeout(() => {
        cards.forEach(card => card.classList.remove("flipped"));
    }, 2000);

    // Update rewards on both pages when starting the game
    updateRewardsOnBothPages();
}

function addToBasket(imageSrc) {
    console.log("Adding to basket:", imageSrc);
    const gameScreenSvg = document.getElementById('gameScreenSvg');
    if (!gameScreenSvg || !gameScreenSvg.contentDocument) {
        console.error('Game screen SVG or its document not available');
        return;
    }
    
    const svgDoc = gameScreenSvg.contentDocument;
    
    // Get the matched cards from the DOM (they're visible on screen)
    const matchedCardElements = document.querySelectorAll('.card.matched');
    if (matchedCardElements.length < 2) {
        console.error('Not enough matched cards found:', matchedCardElements.length);
        return;
    }
    
    // Check if card is fruit or root
    const isFruit = isCardFruit(imageSrc);
    console.log(`Card is a ${isFruit ? 'fruit' : 'root'}`);
    
    // Get target basket
    const targetBasket = isFruit ? svgDoc.getElementById('fruits-basket') : svgDoc.getElementById('roots-basket');
    
    if (!targetBasket) {
        console.error(`${isFruit ? 'Fruits' : 'Roots'} basket not found`);
        return;
    }
    
    // Store the matched card in localStorage for persistence between levels
    if (isFruit) {
        const fruitItems = JSON.parse(localStorage.getItem('fruitItems') || '[]');
        if (!fruitItems.includes(imageSrc)) {
            fruitItems.push(imageSrc);
            localStorage.setItem('fruitItems', JSON.stringify(fruitItems));
        }
    } else {
        const rootItems = JSON.parse(localStorage.getItem('rootItems') || '[]');
        if (!rootItems.includes(imageSrc)) {
            rootItems.push(imageSrc);
            localStorage.setItem('rootItems', JSON.stringify(rootItems));
        }
    }
    
    // First matchedCardElement is the one we'll animate from
    const cardElement = matchedCardElements[0];
    const cardImage = cardElement.querySelector('img'); // This is the actual image in the card
    
    if (!cardImage) {
        console.error('Card image element not found');
        return;
    }
    
    // Create a clone of the actual card image for animation
    const cloneCard = cardImage.cloneNode(true);
    
    // Set initial position and styles
    const cardRect = cardElement.getBoundingClientRect();
    const svgRect = gameScreenSvg.getBoundingClientRect();
    
    // Put the clone in the page with absolute positioning
    cloneCard.style.position = 'absolute';
    cloneCard.style.left = `${cardRect.left}px`;
    cloneCard.style.top = `${cardRect.top}px`;
    cloneCard.style.width = `${cardRect.width}px`;
    cloneCard.style.height = `${cardRect.height}px`;
    cloneCard.style.zIndex = '1000';
    cloneCard.style.borderRadius = '10px';
    cloneCard.style.transform = 'perspective(800px) rotateY(0deg)';
    document.body.appendChild(cloneCard);
    
    // Get basket position for animation target
    const basketRect = targetBasket.getBoundingClientRect();
    
    // Animate with GSAP
    gsap.to(cloneCard, {
        left: basketRect.left + basketRect.width/2 - cardRect.width/2,
        top: basketRect.top + basketRect.height/2 - cardRect.height/2,
        scale: 0.5,
        rotation: Math.random() * 360,
        duration: 1,
        ease: "bounce.out",
        onComplete: function() {
            // Remove the animated clone
            cloneCard.remove();
            
            // Hide the matched cards from the game board
            matchedCardElements.forEach(card => {
                gsap.to(card, {
                    scale: 0,
                    opacity: 0,
                    duration: 0.5
                });
            });
        }
    });
}

function isCardFruit(imageSrc) {
    // Define lists of fruits and roots
    const fruits = [
        "apple", "lemon", "pears", "avocado", "tomato", "grapes", "strawbarry",
        "cherry_blossom", "tulip", "daffodil", "iris", "daisy", "lilac", "pansy", 
        "hyacinth", "magnolia", "lily",
        "maple_leaf", "acorn", "chrysanthemum", "holly", "mistletoe", "winter_berry",
        "frost_leaf", "cardinal"
    ];
    
    const roots = [
        "beetroot", "sweetpatato", "carrot", "turnip", "daikon", "onion",
        "pumpkin", "wheat", "corn", "mushroom", "squash",
        "snowflake", "pine_cone", "evergreen", "icicle", "snow_covered_pine"
    ];
    
    // Check if the image source contains any fruit name
    for (const fruit of fruits) {
        if (imageSrc.toLowerCase().includes(fruit.toLowerCase())) {
            console.log(`Categorized as fruit: ${imageSrc}`);
            return true;
        }
    }
    
    // Check if the image source contains any root name
    for (const root of roots) {
        if (imageSrc.toLowerCase().includes(root.toLowerCase())) {
            console.log(`Categorized as root: ${imageSrc}`);
            return false;
        }
    }
    
    // Default to fruit if uncertain
    console.log(`Could not categorize, defaulting to fruit: ${imageSrc}`);
    return true;
}

function startTimer() {
    elapsedTime = 0;
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        elapsedTime++;
        const minutes = Math.floor(elapsedTime / 60).toString().padStart(2, '0');
        const seconds = (elapsedTime % 60).toString().padStart(2, '0');
        document.getElementById('timer').innerText = `${minutes}:${seconds}`;
    }, 1000);
}

function stopTimer() {
    clearInterval(timerInterval);
}

function resetGameStats() {
    stopTimer();
    elapsedTime = 0;
    moveCount = 0;
    basketIndex = 0; // Reset basket index
    document.getElementById('timer').innerText = '00:00';
    document.getElementById('popupTimer').innerText = '00:00';
    document.getElementById('popupMoves').innerText = '0';
    
    // Clear SVG baskets if they exist
    if (svgBasket1) svgBasket1.innerHTML = '';
    if (svgBasket2) svgBasket2.innerHTML = '';
}

function updateMoveCounter() {
    document.getElementById('popupMoves').innerText = moveCount;
}

function updateRewardsOnBothPages() {
    // Update rewards on the level selection page
    const levelPagePlaceholders = document.querySelectorAll(`#${currentGame}Page .reward-placeholder`);
    rewards[currentGame].forEach((reward, index) => {
        levelPagePlaceholders[index].innerText = reward || "Reward " + (index + 1);
        levelPagePlaceholders[index].style.backgroundColor = reward ? "#4caf50" : "#ccc";
    });

    // Update rewards on the game board page
    const gameBoardPlaceholders = document.querySelectorAll('#gameBoardContainer .reward-placeholder');
    rewards[currentGame].forEach((reward, index) => {
        gameBoardPlaceholders[index].innerText = reward || "Reward " + (index + 1);
        gameBoardPlaceholders[index].style.backgroundColor = reward ? "#4caf50" : "#ccc";
    });
}

function updateSvgRewards() {
    console.log('Updating SVG rewards. Current game:', currentGame, 'Current level:', currentLevel);
    
    // Only proceed if we have the reward elements
    if (!svgWateringCan || !svgSeedsBag || !svgSoilBag) {
        console.log('SVG reward elements not found');
        return;
    }
    
    // Show/hide rewards based on the current game's rewards
    if (rewards[currentGame]) {
        // Level 1 reward - Watering Can
        if (rewards[currentGame][0]) {
            console.log('Showing watering can');
            svgWateringCan.style.opacity = '1';
            svgWateringCan.style.transition = 'opacity 0.5s ease';
        } else {
            svgWateringCan.style.opacity = '0';
        }
        
        // Level 2 reward - Seeds Bag
        if (rewards[currentGame][1]) {
            console.log('Showing seeds bag');
            svgSeedsBag.style.opacity = '1';
            svgSeedsBag.style.transition = 'opacity 0.5s ease';
        } else {
            svgSeedsBag.style.opacity = '0';
        }
        
        // Level 3 reward - Soil Bag
        if (rewards[currentGame][2]) {
            console.log('Showing soil bag');
            svgSoilBag.style.opacity = '1';
            svgSoilBag.style.transition = 'opacity 0.5s ease';
        } else {
            svgSoilBag.style.opacity = '0';
        }
    }
}

function showWinPopup() {
    const minutes = Math.floor(elapsedTime / 60).toString().padStart(2, '0');
    const seconds = (elapsedTime % 60).toString().padStart(2, '0');
    document.getElementById('popupTimer').innerText = `${minutes}:${seconds}`;
    document.getElementById('popupMoves').innerText = moveCount;
    
    // Set the reward for the current level
    if (currentGame && currentLevel > 0 && currentLevel <= 3) {
        rewards[currentGame][currentLevel - 1] = "Earned";
        console.log(`Set reward for ${currentGame}, level ${currentLevel}`);
        
        // Update the reward elements in the SVG
        updateSvgRewards();
    }
    
    document.getElementById('winPopupContainer').style.display = 'flex';
}

function awardRewardForLevel() {
    if (currentGame && currentLevel > 0 && currentLevel <= 3) {
        // Award the appropriate reward based on the level
        rewards[currentGame][currentLevel - 1] = "Earned";
        console.log(`Awarded reward for ${currentGame}, level ${currentLevel}`);
        
        // Update the reward elements in the SVG
        updateSvgRewards();
    }
}

function nextLevel() {
    closeWinPopup();
    if (currentLevel < 3) {
        currentLevel++;
        
        // Clear the fruit and root collections when moving to next level
        localStorage.setItem('fruitItems', JSON.stringify([]));
        localStorage.setItem('rootItems', JSON.stringify([]));
        
        // Reset basket index counter
        basketIndex = 0;
        
        // Make sure we reset the game board first
        const gameBoardElement = document.getElementById("gameBoard");
        if (gameBoardElement) {
            gameBoardElement.innerHTML = '';
        }
        
        // Before starting the next level, ensure game screen is reinitialized
        const gameScreenSvg = document.getElementById('gameScreenSvg');
        if (gameScreenSvg) {
            // Force reload of SVG before starting next level
            gameScreenSvg.data = gameScreenSvg.data;
        }
        
        startGame(currentRows + 1, currentCols + 1, currentGame, currentLevel);
    } else {
        showFinalWinPopup();
    }
}

function exitGame() {
    document.getElementById('winPopupContainer').style.display = 'none';
    goBackToGamePage();
}

function goBackToGamePage() {
    // Clear the fruit and root collections when returning to game page
    localStorage.setItem('fruitItems', JSON.stringify([]));
    localStorage.setItem('rootItems', JSON.stringify([]));
    
    // Reset basket index counter
    basketIndex = 0;
    
    document.getElementById('gameBoardContainer').style.display = 'none';
    document.getElementById(`${currentGame}Page`).style.display = 'block';
}

function showFinalWinPopup() {
    document.getElementById('finalWinPopupContainer').style.display = 'flex';
    // Add your final reward image here
    document.getElementById('finalWinImage').src = "./assets/images/final-reward.jpg"; // Update this path
}

function closeWinPopup() {
    const popup = document.getElementById('winPopupContainer');
    if (popup) {
        popup.style.display = 'none';
    }
}

function closeFinalWinPopup() {
    const popup = document.getElementById('finalWinPopupContainer');
    if (popup) {
        popup.style.display = 'none';
    }
}

function resetGame() {
    selectedCards = [];
    matchedPairs = 0;
    matchedImages = [];
    resetGameStats();
    
    // Clear game board
    const gameBoard = document.getElementById('gameBoard');
    if (gameBoard) {
        gameBoard.innerHTML = '';
    }
}

// Add CSS styles to the document for the basket popups
document.addEventListener('DOMContentLoaded', function() {
    // Create a style element
    const style = document.createElement('style');
    style.textContent = `
        .basket-popup {
            display: none;
            position: absolute;
            width: 200px;
            background-color: white;
            border: 2px solid #333;
            border-radius: 10px;
            padding: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.5);
            z-index: 1000;
        }
        
        .basket-popup h3 {
            margin-top: 0;
            text-align: center;
            color: #333;
        }
        
        .popup-items {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 5px;
            max-height: 150px;
            overflow-y: auto;
        }
        
        .popup-item {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
    `;
    document.head.appendChild(style);
    
    // Initialize localStorage if not already set
    if (!localStorage.getItem('fruitItems')) {
        localStorage.setItem('fruitItems', JSON.stringify([]));
    }
    if (!localStorage.getItem('rootItems')) {
        localStorage.setItem('rootItems', JSON.stringify([]));
    }
});